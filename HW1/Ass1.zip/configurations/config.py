LEARNING_RATE = 0.1
BATCH_SIZE = 20
NUM_EPOCHS = 20
DATASET = 'PeaksData'
DATASETS_NAMES = ['PeaksData']
                  # 'GMMData']